package controle;

import java.sql.PreparedStatement;
import modelo.ModeloCurso;

public class ControleCurso {
    
    ModeloCurso modCurso = new ModeloCurso();
    
    public void inserirCurso(ModeloCurso modCurso) {
        
    }
    
}
