package controle;

import java.sql.*;
import javax.swing.JOptionPane;

public class ConectaBanco {
    
    public Statement stm;//realiza pesquisas no bd
    public ResultSet rs;//armazena resultados da pesquisa
    private String driver = "org.postgresql.Driver";//identifica o servico de bd
    private String caminho = "jdbc:postgresql://localhost:5432/moraisparking";//identifica o local do bd
    private String usuario = "postgres";
    private String senha = "123456";
    public Connection conn;//realiza a conexao com o bd
    
    public void conexao() { //metodo que realiza a conexao com o bd
        try {
            System.setProperty("jdbc.Drivers", driver);
            conn = DriverManager.getConnection(caminho, usuario, senha);
            //JOptionPane.showMessageDialog(null,"Banco de Dados Conectado!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro de conexão: "+ex.getMessage());
        }
    }
    
    public void desconecta () { //metodo para fechar conexao com o bd
        try {
            conn.close();
            JOptionPane.showMessageDialog(null,"Banco de Dados Desconectado!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao fechar conexão: "+ex.getMessage());
        }
    }
    
}