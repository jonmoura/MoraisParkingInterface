package modelo;

public class ModeloCurso {
    
    private String nome;
    private int id; //Representacao de valor unico para cada registro de cada curso

    public ModeloCurso() {

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
}