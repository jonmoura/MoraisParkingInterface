package moraisparking;

import visao.TelaLogin;

public class MoraisParking {

    public static void main(String[] args) {
        
        TelaLogin tela = new TelaLogin();
        tela.setVisible(true);
        
    }
    
}
